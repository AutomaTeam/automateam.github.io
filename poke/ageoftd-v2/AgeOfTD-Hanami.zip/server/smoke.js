// Test de fumée du relais : handshake, routage input→hôte, snap→invités.
'use strict';
process.env.PORT = process.env.PORT || '8799';
require('./relay.js');                       // démarre le relais sur PORT
const WebSocket = require('ws');
const URL = 'ws://localhost:' + process.env.PORT;

let passed = 0, failed = 0;
const ok = (c, m) => { c ? (passed++, console.log('  ✓ ' + m)) : (failed++, console.log('  ✗ ' + m)); };
const C = () => new WebSocket(URL);
const sj = (ws, o) => ws.send(JSON.stringify(o));

let roomCode = null, host, guest;

host = C();
host.on('open', () => sj(host, { k: 'join', room: '', name: 'Hôte' }));
host.on('message', d => {
  const m = JSON.parse(d);
  if (m.k === 'welcome') {
    ok(m.isHost === true, 'hôte reçoit welcome isHost=true');
    ok(typeof m.room === 'string' && m.room.length === 4, 'code de salle généré (' + m.room + ')');
    roomCode = m.room;
    guest = C();
    guest.on('open', () => sj(guest, { k: 'join', room: roomCode, name: 'Pote' }));
    guest.on('message', d2 => {
      const g = JSON.parse(d2);
      if (g.k === 'welcome') {
        ok(g.isHost === false, 'invité reçoit welcome isHost=false');
        ok(g.room === roomCode, 'invité dans la même salle');
        sj(guest, { k: 'input', cmd: { k: 'build', key: 'archer', c: 3, r: 1 } });
      }
      if (g.k === 'snap') {
        ok(g.go === 123 && Array.isArray(g.en), 'invité reçoit le snapshot de l\'hôte');
        finish();
      }
    });
  }
  if (m.k === 'peer_join') ok(m.name === 'Pote', 'hôte notifié de l\'arrivée (peer_join)');
  if (m.k === 'input') {
    ok(m.cmd && m.cmd.key === 'archer' && m.from, 'input invité routé vers l\'hôte (avec from)');
    sj(host, { k: 'snap', go: 123, en: [], tw: [] });   // l'hôte répond par un snapshot
  }
});

function finish() {
  console.log(`\nRésultat : ${passed} OK / ${failed} KO`);
  try { host.close(); guest.close(); } catch (e) {}
  process.exit(failed ? 1 : 0);
}
setTimeout(() => { console.log('⏱️ timeout — protocole bloqué'); process.exit(1); }, 4000);
