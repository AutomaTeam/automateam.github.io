// ============================================================
// AgeOfTD V2 — relay.js : relais WebSocket pour le co-op
// ------------------------------------------------------------
// Serveur volontairement « bête » : il ne simule rien. Il route
// les messages d'une salle :
//   - 'input'  (invité) → vers l'HÔTE uniquement
//   - le reste (snap/start/cursor…) → vers les AUTRES de la salle
// Le premier connecté d'une salle en devient l'hôte (autorité).
//
// Lancer :  cd v2/server && npm install && npm start
// Variable d'env PORT (def. 8787).
// ============================================================
'use strict';

const { WebSocketServer } = require('ws');

const PORT = parseInt(process.env.PORT, 10) || 8787;
const wss = new WebSocketServer({ port: PORT });

const rooms = new Map();        // code -> { hostId, clients: Map(id -> ws) }
let nextId = 1;

// Borne de taille : un snapshot hôte plein (~80 projectiles, ennemis, tours…)
// reste bien en deçà ; au-delà on droppe pour ne pas inonder la salle.
const MAX_MSG = 512 * 1024;

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';   // sans I/O/0/1 ambigus
function newCode() {
  let c;
  do { c = Array.from({ length: 4 }, () => ALPHABET[Math.floor(Math.random() * ALPHABET.length)]).join(''); }
  while (rooms.has(c));
  return c;
}

const send = (ws, obj) => { if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj)); };

wss.on('connection', ws => {
  ws._id = null; ws._room = null; ws._name = 'Joueur';

  ws.on('message', data => {
    if (data && data.length > MAX_MSG) return;   // message hors-norme → drop
    let m;
    try { m = JSON.parse(data); } catch (e) { return; }

    if (m.k === 'join') return handleJoin(ws, m);

    const room = rooms.get(ws._room);
    if (!room) return;

    if (m.k === 'input') {
      send(room.clients.get(room.hostId), { k: 'input', cmd: m.cmd, from: ws._id });
    } else {
      // l'identité du curseur vient du serveur, pas du payload (anti-usurpation)
      if (m.k === 'cursor') m.id = ws._id;
      // snap / start / cursor / chat → tous les autres de la salle
      for (const [id, c] of room.clients) if (id !== ws._id) send(c, m);
    }
  });

  ws.on('close', () => handleClose(ws));
  ws.on('error', () => {});
});

function handleJoin(ws, m) {
  let code = (m.room || '').toUpperCase().trim();
  if (!code) { code = newCode(); rooms.set(code, { hostId: null, clients: new Map() }); }

  const room = rooms.get(code);
  if (!room) { send(ws, { k: 'err', msg: 'Partie introuvable : ' + code }); return; }
  if (room.clients.size >= 6) { send(ws, { k: 'err', msg: 'Salon plein (6 max)' }); return; }

  const id = nextId++;
  ws._id = id; ws._room = code; ws._name = String(m.name || 'Joueur').slice(0, 12);

  const peers = [...room.clients.values()].map(c => ({ id: c._id, name: c._name }));
  const isHost = room.hostId === null;
  if (isHost) room.hostId = id;
  room.clients.set(id, ws);

  send(ws, { k: 'welcome', id, isHost, room: code, peers });
  for (const [pid, c] of room.clients) if (pid !== id) send(c, { k: 'peer_join', id, name: ws._name });
  console.log(`[relay] ${ws._name} (#${id}) ${isHost ? 'a créé' : 'a rejoint'} la salle ${code} — ${room.clients.size} joueur(s)`);
}

function handleClose(ws) {
  const room = rooms.get(ws._room);
  if (!room) return;
  room.clients.delete(ws._id);
  const wasHost = room.hostId === ws._id;
  for (const [, c] of room.clients) send(c, wasHost ? { k: 'host_left' } : { k: 'peer_leave', id: ws._id });
  if (wasHost || room.clients.size === 0) { rooms.delete(ws._room); console.log(`[relay] salle ${ws._room} fermée`); }
}

console.log(`🏮 Relais co-op AgeOfTD V2 à l'écoute sur ws://0.0.0.0:${PORT}`);
console.log('   Les amis sur le même réseau se connectent à ws://<ton-ip-locale>:' + PORT);
